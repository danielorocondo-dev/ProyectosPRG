package com.ieseljust.ad.myDBMS;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

class ConnectionManager {

    String server;
    String port;
    String user;
    String pass;

    ConnectionManager() {
        // TO-DO: Init default values
        this.server = "localhost";
        this.port = "3308";
        this.user = "root";
        this.pass = "root";
    }

    ConnectionManager(String server, String port, String user, String pass) {
        // TO-DO:   Init with arguments
        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;
    }

    public Connection connectDBMS() {

        // TO-DO:  Create a connection, 
        // Returns this or null.
        // Remember error management
        String connectionUrl = "jdbc:mysql://" + this.server + ":" + this.port + "/?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF-8&user=" + this.user + "&password=" + this.pass;
        try {
            Connection con = DriverManager.getConnection(connectionUrl);
            return con;
        } catch (SQLException e) {
            System.out.println("Error" + e.getMessage() + " estado: " + e.getSQLState());
            return null;
        }
    }

    public void showInfo() {
        // TO-DO: show server info
        // Remember error management
        Connection con = connectDBMS();
        if (con != null) {
            DatabaseMetaData dades;
            try {
                dades = con.getMetaData();
                System.out.println("El SGBD actual és " + dades.getDatabaseProductName());
                System.out.println("Driver " + dades.getDriverName() + " versio " + dades.getDriverVersion());
                System.out.println("URL de connexió " + dades.getURL());
                System.out.println("Usuari actual " + dades.getUserName());
            } catch (SQLException e) {
                System.out.println("Error " + e.getMessage());
                Logger.getLogger(ConnectionManager.class.getName()).log(Level.SEVERE, null, e);
            }
        } else {
            System.out.println("Error al conectarse a la base de datos");
        }
    }

    public void showDatabases() {
        // TO-DO: Show databases in your server  
        Connection conn = connectDBMS();
        if (conn != null) {
            try {
                String query = "SHOW DATABASES;";
                ResultSet rs;
                try (Statement st = conn.createStatement()) {
                    rs = st.executeQuery(query);
                    while (rs.next()) {
                        System.out.println(rs.getString(1));
                    }
                }
                rs.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("Error " + ex.getMessage() + " Estado: " + ex.getSQLState());
            }
        } else {
            System.out.println("No se ha podido crear la conexion");
        }
    }

    public void startShell() {

        Scanner keyboard = new Scanner(System.in);
        String comanda;

        do {

            System.out.print(ConsoleColors.GREEN_BOLD_BRIGHT + "# (" + this.user + ") on " + this.server + ":" + this.port + "> " + ConsoleColors.RESET);
            comanda = keyboard.nextLine();

            switch (comanda) {
                case "help" -> {
                    System.out.println("\n\n\t\t" + ConsoleColors.YELLOW_UNDERLINED + "Us del Manager de AD" + ConsoleColors.RESET);
                    System.out.println(ConsoleColors.YELLOW_BOLD_BRIGHT + "show databases o sh db\t\tMostra les bases de dades" + ConsoleColors.RESET);
                    System.out.println(ConsoleColors.YELLOW_BOLD_BRIGHT + "info\t\t\t\tMostra informació de la connexió" + ConsoleColors.RESET);
                    System.out.println(ConsoleColors.YELLOW_BOLD_BRIGHT + "import Nom_del_script\t\tCarrega un script en la BBDD" + ConsoleColors.RESET);
                    System.out.println(ConsoleColors.YELLOW_BOLD_BRIGHT + "use Nom_de_la_BD\t\tActiva la BBDD indicada i canvia el mode del menú" + ConsoleColors.RESET);
                    System.out.println(ConsoleColors.YELLOW_BOLD_BRIGHT + "help\t\t\t\tAjuda de l'aplicació\n\n" + ConsoleColors.RESET);
                }
                case "sh db", "show databases" ->
                    this.showDatabases();
                case "info" ->
                    this.showInfo();

                case "quit" -> {
                }

                default -> {
                    // Com que no podem utilitzar expressions
                    // regulars en un case (per capturar un "use *")
                    // busquem aquest cas en el default:
                    String[] subcomanda = comanda.split(" ");
                    switch (subcomanda[0]) {
                        case "use" -> {
                            // TO-DO:
                            // Creem un objecte de tipus databaseManager per connectar-nos a
                            // la base de dades i iniciar una shell de manipulació de BD..
                            try {
                                DatabaseManager dbManager = new DatabaseManager(this.server, this.port, this.user, this.pass, subcomanda[1]);
                                Connection con = dbManager.connectDatabase();
                                if (con != null) {
                                    dbManager.startShell();
                                } else {
                                    System.out.println("Error al conectar a la base de datos");
                                }
                                break;
                            } catch (Exception e) {
                                System.out.println("Error, argumentos no validos");
                            }
                        }
                        case "import" -> {
                            try {
                                String linea;
                                String query = "";
                                File f = new File(subcomanda[1]);
                                if (f.exists() && f.isFile() && f.getName().endsWith(".sql")) {
                                    try {
                                        BufferedReader br = new BufferedReader(new FileReader(f));
                                        while ((linea = br.readLine()) != null) {
                                            query += linea + "\n";
                                        }
                                        System.out.println(query);
                                    } catch (IOException e) {
                                        System.out.println(e.getMessage());
                                    }
                                    try {
                                        Connection conn = this.connectDBMS();
                                        Statement pst = conn.createStatement();
                                        int afectedRows = pst.executeUpdate(query);
                                        System.out.println(afectedRows);
                                    } catch (SQLException e) {
                                        System.out.println("Error " + e.getMessage() + "\nEstado : " + e.getSQLState());
                                    }
                                } else {
                                    System.out.println("Error");
                                }
                            } catch (Exception e) {
                                System.out.println("Error, debes indicar correctamente la ruta del script.sql");
                            }

                        }
                        default ->
                            System.out.println("Opcio no permitida");
                    }
                }
            }

        } while (!comanda.equals("quit"));

    }

}
