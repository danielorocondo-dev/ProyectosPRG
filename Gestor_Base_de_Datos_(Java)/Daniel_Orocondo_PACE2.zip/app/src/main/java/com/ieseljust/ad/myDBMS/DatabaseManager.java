package com.ieseljust.ad.myDBMS;

import java.sql.*;
import java.util.Scanner;

class DatabaseManager {

    String server;
    String port;
    String user;
    String pass;
    String dbname;
    Connection connection;
    Scanner teclat = new Scanner(System.in);

    DatabaseManager() {
        // TO-DO: Default initialization
        this.server = "localhost";
        this.port = "3308";
        this.user = "root";
        this.pass = "root";
        this.dbname = "danibase";
    }

    DatabaseManager(String server, String port, String user, String pass, String dbname) {
        // TO-DO: Init from args
        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;
        this.dbname = dbname;
    }

    public Connection connectDatabase() {
        // TO-DO: Connect to a specific database
        try {
            String url = "jdbc:mysql://" + this.server + ":" + this.port + "/" + this.dbname;
            this.connection = DriverManager.getConnection(url, this.user, this.pass);
            return this.connection;
        } catch (SQLException e) {
            System.out.println("Error al conectar" + e.getMessage());
            return null;
        }
    }

    public void showTables() {
        // TO-DO: Show the tables in this database
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SHOW TABLES");
            System.out.println("Tablas en la base de datos: " + this.dbname + ":");
            while (rs.next()) {
                System.out.println(rs.getString(1));
            }
        } catch (SQLException e) {
            System.out.println("Error al mostrar tablas " + e.getMessage());
        }
    }

    public void mostraTaula(String sentencia) {
        Connection con = this.connectDatabase();
        if (con != null) {
            try {
                PreparedStatement pst = con.prepareStatement(sentencia);
                ResultSet rs = pst.executeQuery();
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnCount = rsmd.getColumnCount();
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(rsmd.getColumnName(i) + "\t\t");
                }
                System.out.println();
                while (rs.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        System.out.print(rs.getString(i) + "\t\t");
                    }
                    System.out.println();
                }
            } catch (SQLException ex) {
                System.out.println("Error, expresion no valida");
            }
        } else {
            System.out.println("Error con la conexión a la base de datos");
        }
    }

    public void insertarTabla() {
        Connection con = this.connectDatabase();
        Scanner scann = new Scanner(System.in);

        if (con != null) {
            System.out.print("Dime la tabla: ");
            String taula = scann.nextLine();

            try {
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM " + taula);
                if (!rs.next()) {
                    System.out.println("La tabla no existe");
                } else {
                    ResultSetMetaData rsmd = rs.getMetaData();
                    StringBuilder columnes = new StringBuilder();
                    StringBuilder valors = new StringBuilder();

                    for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                        System.out.print("La columna " + rsmd.getColumnName(i) + " es del tipo " + rsmd.getColumnTypeName(i) + ". ¿Quieres insertarla? (s/n): ");
                        String insert = scann.nextLine();

                        if (insert.equalsIgnoreCase("s") || insert.equalsIgnoreCase("si")) {
                            columnes.append(rsmd.getColumnName(i)).append(",");
                            switch (rsmd.getColumnTypeName(i).toLowerCase()) {
                                case "int" -> {
                                    System.out.print("Valor (int): ");
                                    valors.append(scann.nextInt()).append(",");
                                    scann.nextLine();
                                }

                                case "double" -> {
                                    System.out.print("Valor (double): ");
                                    valors.append(scann.nextDouble()).append(",");
                                    scann.nextLine();
                                }

                                case "float" -> {
                                    System.out.print("Valor (float): ");
                                    valors.append(scann.nextFloat()).append(",");
                                    scann.nextLine();
                                }

                                case "char" -> {
                                    System.out.print("Valor (char): ");
                                    valors.append("'").append(scann.nextLine().charAt(0)).append("',");
                                }

                                case "varchar" -> {
                                    System.out.print("Valor (varchar): ");
                                    valors.append("'").append(scann.nextLine()).append("',");
                                }
                            }
                        }
                    }
                    if (columnes.length() > 0 && valors.length() > 0) {
                        columnes.setLength(columnes.length() - 1);
                        valors.setLength(valors.length() - 1);
                    }

                    String query = "INSERT INTO " + taula + " (" + columnes + ") VALUES (" + valors + ")";
                    PreparedStatement pst = con.prepareStatement(query);
                    pst.executeUpdate();
                    System.out.println("Inserción completada.");
                }

            } catch (SQLException ex) {
                System.out.println("Error: " + ex.getMessage() + "\nEstado: " + ex.getSQLState());
            }
        }
    }

    public void mostraInfo(String table) {
        // Conectar a la base de datos
        Connection con = this.connectDatabase();
        if (con != null) {
            StringBuilder plantillaInfo = new StringBuilder();
            try {
                String query = "SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_KEY "
                        + "FROM information_schema.COLUMNS "
                        + "WHERE TABLE_SCHEMA = '" + this.dbname + "' "
                        + "AND TABLE_NAME = '" + table + "';";

                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                if (rs.next()) {
                    plantillaInfo.append(String.format("%-15s %-20s %-10s %-5s\n", "COLUMN", "TYPE", "NULLABLE", "KEY"));
                    plantillaInfo.append("-------------------------------------------------------------\n");
                } else {
                    System.out.println("Tabla no encontrada en la base de datos");
                }
                while (rs.next()) {
                    String columnName = rs.getString("COLUMN_NAME");
                    String columnType = rs.getString("COLUMN_TYPE");
                    String isNullable = rs.getString("IS_NULLABLE");
                    String columnKey = rs.getString("COLUMN_KEY");
                    plantillaInfo.append(String.format("%-15s %-20s %-10s %-5s\n", columnName, columnType, isNullable, columnKey));
                }
                System.out.print(plantillaInfo.toString());
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (SQLException e) {
                    System.out.println("Error cerrando conexión " + e.getMessage());
                }
            }
        } else {
            System.out.println("No se ha podido conectar a la base de datos");
        }
    }

    public void showRegisters(String tabla) {
        // TO-DO: Show the data inside a specific table
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + tabla);
            ResultSetMetaData md = rs.getMetaData();
            int columnCount = md.getColumnCount();

            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(rs.getString(i) + "\t");
                }
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println("Error al mostrar registros " + e.getMessage());
        }
    }

    public void startShell() {
        // TO-DO: Inicia la shell del mode base de dades
        String comand;

        do {
            System.out.print("# (" + this.user + ") on " + this.server + ":" + this.port + "[" + dbname + "]>");
            comand = teclat.nextLine();
            String[] comandParts = comand.split(" ", 2);

            switch (comandParts[0]) {
                case "help" -> {
                    System.out.println("\n\n\t\t" + ConsoleColors.YELLOW_UNDERLINED + "Gestor de la BBDD " + this.dbname + ConsoleColors.RESET);
                    System.out.print("show tables o sh tb\t\t");
                    System.out.println("Mostra les taules de la base de dades");
                    System.out.print("describe o desc\t\t\t");
                    System.out.println("Mostra informació de una taula");
                    System.out.print("insert\t\t\t\t");
                    System.out.println("Inserix informació de forma interactiva a la taula");
                    System.out.print("select\t\t\t\t");
                    System.out.println("Pregunta que es vols mostrar i executa la consulta");
                    System.out.print("quit\t\t\t\t");
                    System.out.println("Retorna al menú de l'SGBD");
                    System.out.print("help\t\t\t\t");
                    System.out.println("Ajuda de l'aplicació");
                }
                case "select" -> {
                    try {
                        this.mostraTaula(comand);
                    }catch (Exception e) {
                    }
                }
                case "insert" -> {
                    try {
                        this.insertarTabla();
                    }catch (Exception e) {
                        System.out.println("Error, sentencia incorrecta");
                    }
                }
                case "show" -> {
                    try {
                        if (comandParts.length > 1 && comandParts[1].equals("tables")) {
                            this.showTables();
                        } else {
                            System.out.println("No es una opció valida");
                        }
                    }catch (Exception e) {
                        System.out.println("Error, sentencia incorrecta");
                    }
                }
                case "sh" -> {
                    try {
                        if (comandParts.length > 1 && comandParts[1].equals("tb")) {
                            this.showTables();
                        } else {
                            System.out.println("No es una opció valida");
                        }
                    }catch (Exception e) {
                        System.out.println("Error, sentencia incorrecta");
                    }
                }

                case "describe", "desc" -> {
                    try {
                        this.mostraInfo(comandParts[1]);
                    } catch (Exception e) {
                        System.out.println("Error, sentencia incorrecta");
                    }
                }
                case "quit" -> {
                }
                default -> System.out.println("No es una opció valida");
            }
        } while (!comand.equals("quit"));
    }
}
