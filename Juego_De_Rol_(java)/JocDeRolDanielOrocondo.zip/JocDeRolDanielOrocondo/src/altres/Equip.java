package altres;

import java.util.ArrayList;
import java.util.Objects;
import personajes.Jugador;

public class Equip {

    //atributos
    private String nom;
    public ArrayList<Jugador> jugadors = new ArrayList();

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Equip other = (Equip) obj;
        return Objects.equals(this.nom, other.nom);
    }

    //metodos
    public void posa(Jugador jug1) {
        //controlador de sobreposición de jugador
        if (this.jugadors.contains(jug1) == false) { 
            this.jugadors.add(jug1);
            jug1.setEquipo(this);
            System.out.println("Se ha añadido " + jug1.getNom() + " a el equipo " + this.nom);
        } else {
            System.out.println(jug1.getNom() + "ya esta dentro del equipo " + this.nom);
        }
    }

    public void lleva(Jugador nom) {
        if (this.jugadors.contains(nom) == true) {
            this.jugadors.remove(nom);
            nom.setEquipo(null);
            System.out.println("Se ha eliminado " + nom.getNom() + " a el equipo " + this.nom);
        } else {
            System.out.println(nom.getNom() + " no esta en el equipo " + this.nom);
        }
    }

    @Override
    public String toString() {
        String x = "Equip " + this.nom + ":\n";
        for (Jugador jugador : this.jugadors) {
            jugador.toString();
            x += " - " + jugador + ")\n";
        }
        return x;
    }
    //constructors

    public Equip(String nom) {
        this.nom = nom;
    }

    //getters y setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

}
