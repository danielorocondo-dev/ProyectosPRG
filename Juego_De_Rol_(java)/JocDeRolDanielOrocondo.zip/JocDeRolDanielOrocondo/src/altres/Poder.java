package altres;

public class Poder {

    private String nom;
    private int bonusAtaque;
    private int bonusDefensa;

    public Poder(String nom, int bonusAtaque, int bonusDefensa) {
        this.nom = nom;
        this.bonusAtaque = bonusAtaque;
        this.bonusDefensa = bonusDefensa;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getBonusAtaque() {
        return bonusAtaque;
    }

    public void setBonusAtaque(int bonusAtaque) {
        this.bonusAtaque = bonusAtaque;
    }

    public int getBonusDefensa() {
        return bonusDefensa;
    }

    public void setBonusDefensa(int bonusDefensa) {
        this.bonusDefensa = bonusDefensa;
    }

    @Override
    public String toString() {
        return nom + " ( BA:" + bonusAtaque + ", BD:" + bonusDefensa + ")";
    }

}
