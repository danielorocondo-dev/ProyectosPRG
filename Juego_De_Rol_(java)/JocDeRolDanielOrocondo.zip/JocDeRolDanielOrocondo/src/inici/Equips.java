package inici;

import java.util.ArrayList;
import altres.Equip;
import teclat.Teclat;

public class Equips {

    protected static ArrayList<Equip> lista = new ArrayList();

    public static ArrayList<Equip> getLista() {
        return lista;
    }

    static void menu() {
        boolean menuConf = true;
        do {
            int opcion = Teclat.lligOpcio("EQUIPOS", "Crear", "Consultar", "Eliminar");
            switch (opcion) {
                case 1:
                    crear();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 0:
                    menuConf = false;
                    break;
            }
        } while (menuConf);
    }

    private static void crear() {
        String nomEqu = Teclat.lligString("Dime el nombre del equipo nuevo:");
        if (lista.contains(new Equip(nomEqu))) {
            System.out.println("ya hay un equipo registrado con ese nombre, cambialo");
        } else {
            Equip e1 = new Equip(nomEqu);
            lista.add(e1);
        }
    }

    private static void consultar() {
        for (Equip equip : lista) {
            System.out.println(equip);
        }
    }

    private static void eliminar() {
        for (Equip equip : lista) {
            System.out.println(equip);
        }
        String nomRemove = Teclat.lligString("Dime el nombre del equipo que quieres eliminar");
        lista.remove(new Equip(nomRemove));
    }

}
