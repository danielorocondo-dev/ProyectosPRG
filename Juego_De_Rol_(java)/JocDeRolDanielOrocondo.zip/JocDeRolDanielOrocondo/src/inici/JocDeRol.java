package inici;

import static inici.Jugadors.lista;
import java.util.Random;
import personajes.Jugador;

import teclat.*;

public class JocDeRol {

    public static void main(String[] args) {
        boolean jugarRol = true;
        do {
            int opcion = Teclat.lligOpcio("JUEGO DE ROL", "Configuración", "Jugar");
            switch (opcion) {
                case 1:
                    menuConfiguracion();
                    break;
                case 2:
                    Jugadors.daniprova();
                    jugar();
                    jugarRol = false;
                    break;
                case 0:
                    jugarRol = false;
                    break;
                default:
                    System.out.println("Opció no vàlida.\n Escoge entre Configuración, jugar o salir");
                    break;
            }

        } while (jugarRol);
    }

    private static void menuConfiguracion() {
        boolean menuConf = true;
        do {
            int opcion = Teclat.lligOpcio("CONFIGURACIO", "Jugador", "Equipos", "Poders");
            switch (opcion) {
                case 1:
                    Jugadors.menu();
                    break;
                case 2:
                    Equips.menu();
                    break;
                case 3:
                    Poders.menu();
                    break;
                case 0:
                    menuConf = false;
                    break;
            }
        } while (menuConf);

    }

    private static void jugar() {
        boolean jugarPar = true;
        int numJug = Jugadors.lista.size();
        System.out.println(numJug);
        Random random = new Random();
        Random random2 = new Random();
        do {
            if (numJug < 2) {
                for (Jugador jugador : lista) {
                    if (jugador.getVides() > 0) {
                        System.out.println(jugador.getNom() + " ha ganado la partida");
                    }
                }
                jugarPar = false;
            } else {
                for (Jugador jugador : lista) {
                    if (jugador.getVides() > 0) {
                        --numJug;
                    }
                }
                int numRand1 = random.nextInt(numJug);
                int numRand2 = random2.nextInt(numJug);
                Jugadors.lista.get(numRand1).ataca(Jugadors.lista.get(numRand2));
            }
        } while (jugarPar);
    }
}
