package inici;

import altres.*;
import java.util.ArrayList;
import personajes.Alien;
import personajes.Guerrero;
import personajes.Humano;
import personajes.Jugador;
import teclat.Teclat;

public class Jugadors {

    protected static ArrayList<Jugador> lista = new ArrayList();
    static int videsInicials = 200;

    static void menu() {
        boolean menuConf = true;
        do {
            int opcionw = Teclat.lligOpcio("JUGADORS", "Crear", "Consultar", "Eliminar", "Asignar a un equipo", "Eliminar de un equipo", "Asignar poder");
            switch (opcionw) {
                case 1:
                    crear();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    asignarEquipo();
                    break;
                case 5:
                    asignarPoder();
                    break;
                case 6:
                    eliminar();
                    break;
                case 0:
                    menuConf = false;
                    break;
            }
        } while (menuConf);
    }

     static void daniprova() {
        Guerrero g1 = new Guerrero("dani", 50, 50, videsInicials);
        Humano h1 = new Humano("alex", 5, 95, videsInicials);
    }

    private static void crear() {
        char tipoJugador = Teclat.lligChar("Que tipo de jugador quieres crear? (Humano, Guerrero, Alien)", "HGA");
        String nomJug = Teclat.lligString("Dime el nombre del jugador:");
        int pAtaque = Teclat.lligInt("Dime la cantida de puntos de ataque", 1, 100);
        int pDefensa = 100 - pAtaque;
        if (lista.contains(new Jugador(nomJug, 0, 0, 0))) {
            System.out.println("ya hay un jugador registrado con ese nombre, cambialo");
        }
        switch (tipoJugador) {
            case 'H':
                Humano j1 = new Humano(nomJug, pAtaque, pDefensa, videsInicials);
                lista.add(j1);
                break;
            case 'G':
                Guerrero g1 = new Guerrero(nomJug, pAtaque, pDefensa, videsInicials);
                lista.add(g1);
                break;
            case 'A':
                Alien a1 = new Alien(nomJug, pAtaque, pDefensa, videsInicials);
                lista.add(a1);
                break;
        }
    }

    private static void consultar() {
        for (Jugador jugador : lista) {
            System.out.println(jugador);
        }
    }

    private static void eliminar() {
        for (Jugador jugador : lista) {
            System.out.println(jugador);
        }
        String nomRemove = Teclat.lligString("Dime el nombre del jugador que quieres eliminar");
        lista.remove(new Jugador(nomRemove, 0, 0, 0));
    }

    private static void asignarEquipo() {
        String nomJugador = Teclat.lligString("Dime el nombre del jugador que quieras añadir a un equipo");
        String nomEquipo = Teclat.lligString("Dime el nombre del equipo al que quieras añadir");
        int jugFals = lista.indexOf(new Jugador(nomJugador, 0, 0, 0));
        int equipFals = Equips.lista.indexOf(new Equip(nomEquipo));
        if (equipFals != -1 && jugFals != -1) {
            Equip eq = Equips.lista.get(equipFals);
            Jugador jug = lista.get(jugFals);
            eq.posa(jug);
        }

        //POR TERMINAR
    }

    private static void asignarPoder() {
        String nomJugador = Teclat.lligString("Dime el nombre del jugador que quieras añadir a un equipo");
        String nomPoder = Teclat.lligString("Dime el nombre del poder al que quieras añadir");
        int jugFals = lista.indexOf(new Jugador(nomJugador, 0, 0, 0));
        int poderFals = Equips.lista.indexOf(new Equip(nomPoder));
        if (poderFals != -1 && jugFals != -1) {
            Poder poder = Poders.lista.get(poderFals);
            Jugador jug = lista.get(jugFals);
            jug.posa(poder);
        }

    }
}
