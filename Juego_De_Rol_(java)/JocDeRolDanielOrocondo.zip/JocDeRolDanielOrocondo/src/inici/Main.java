
import java.util.ArrayList;

class MiObjeto {

    private final String nombre;

    public MiObjeto(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}

public class Main {

    public static void main(String[] args) {
        // Crear un ArrayList y agregar algunos objetos
        ArrayList<MiObjeto> lista = new ArrayList<>();
        lista.add(new MiObjeto("Objeto1"));
        lista.add(new MiObjeto("Objeto2"));
        lista.add(new MiObjeto("Objeto3"));

        // Posición del objeto que queremos obtener
        int posicion = 1; // por ejemplo, queremos el segundo objeto (índice 1)

        // Obtener el objeto en la posición especificada y mostrar su nombre
        MiObjeto objeto = lista.get(posicion);
        System.out.println(objeto.getNombre());
    }
}
