package inici;

import java.util.ArrayList;
import altres.Poder;
import teclat.Teclat;

public class Poders {

    protected static ArrayList<Poder> lista = new ArrayList();

    static void menu() {
        boolean menuConf = true;
        do {
            int opcion = Teclat.lligOpcio("PODERES", "Crear", "Consultar", "Eliminar poder");
            switch (opcion) {
                case 1:
                    crear();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 0:
                    menuConf = false;
                    break;
            }
        } while (menuConf);
    }

    private static void crear() {
        String nomPod = Teclat.lligString("Dime el nombre del equipo nuevo:");
        int qPuntsAtaque = Teclat.lligInt("Dime los puntos de ataque del poder");
        int qPuntsDefensa = Teclat.lligInt("Dime los puntos de defensa del poder");
        if (lista.contains(new Poder(nomPod, 0, 0))) {
            System.out.println("ya hay un equipo registrado con ese nombre, cambialo");
        } else {
            Poder e1 = new Poder(nomPod, qPuntsAtaque, qPuntsDefensa);
            lista.add(e1);
        }
    }

    private static void consultar() {
        for (Poder poder : lista) {
            System.out.println(poder);
        }
    }

    private static void eliminar() {
        for (Poder poder : lista) {
            System.out.println(poder);
        }
        String nomRemove = Teclat.lligString("Dime el nombre del equipo que quieres eliminar");
        lista.remove(new Poder(nomRemove, 0, 0));
    }
}
