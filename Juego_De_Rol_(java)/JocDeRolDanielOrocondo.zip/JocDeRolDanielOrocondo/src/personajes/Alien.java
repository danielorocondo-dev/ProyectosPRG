package personajes;

import altres.Poder;

public class Alien extends Jugador {

    public Alien(String nom, int puntosAtaque, int puntosDefensa, int vides) {
        super(nom, puntosAtaque, puntosDefensa, vides);
        System.out.println("Soy un constructor de Alien pero estoy creando un " + this.getClass().getSimpleName());
    }

    @Override
    public void ataca(Jugador p1) {
        System.out.println(this);
        System.out.println(p1);
        //jugador uno es this
        //jugador dos es p1
        int ataqueExtra = 0;
        int ataqueExtrap1 = 0;
        for (Poder podere : this.getPoderes()) {
            if (this.getPoderes().contains(podere)) {
                ataqueExtra += podere.getBonusAtaque();
            }

            if (p1.getPoderes().contains(podere)) {
                ataqueExtrap1 += podere.getBonusAtaque();
            }
        }
        if (this.getVides() > 20) {
            this.setPuntosAtaque(this.getPuntosAtaque() + 3);
            this.setPuntosDefensa(this.getPuntosDefensa() - 3);
        }
        if ("Alien".equals(p1.getClass().getSimpleName())) {
            if (p1.getVides() > 20) {
                p1.setPuntosAtaque(p1.getPuntosAtaque() + 3);
                p1.setPuntosDefensa(p1.getPuntosDefensa() - 3);
            }
        }
        this.esGolpeadoConCantidad(p1.getPuntosAtaque() + ataqueExtrap1);
        p1.esGolpeadoConCantidad(this.getPuntosAtaque() + ataqueExtra);

        if (this.getVides() > 0) {
            System.out.println(this);
        } else {
            System.out.println(this.getNom() + " ha muerto");
        }

        if (p1.getVides() > 0) {
            System.out.println(p1);
        } else {
            System.out.println(p1.getNom() + " ha muerto");
        }
    }
}
