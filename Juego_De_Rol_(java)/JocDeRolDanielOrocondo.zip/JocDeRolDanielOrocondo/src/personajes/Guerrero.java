package personajes;

import altres.Poder;

public class Guerrero extends Humano {

    public Guerrero(String nom, int puntosAtaque, int puntosDefensa, int vides) {
        super(nom, puntosAtaque, puntosDefensa, vides);
        System.out.println("Soy un constructor de Guerrero pero estoy creando un " + this.getClass().getSimpleName());
    }

    @Override
    protected void esGolpeadoConCantidad(int qPuntosAtaque) {
        int defensaExtra = 0;
        for (Poder podere : this.getPoderes()) {
            if (this.getPoderes().contains(podere)) {
                defensaExtra += podere.getBonusDefensa();
            }
        }
        if (this.getPuntosDefensa() + defensaExtra > 0) {
            qPuntosAtaque -= this.getPuntosDefensa() + defensaExtra;
            if (qPuntosAtaque < 5) {
                System.out.println(this.getNom() + " es golpeado con " + (qPuntosAtaque + this.getPuntosDefensa()) + " puntos y se defiende con " + this.getPuntosDefensa() + ". No es herido, dado a su entrenamiento como Guerrero");
            } else {
                this.setVides(this.getVides() - qPuntosAtaque);
                if (this.getVides() > 0) {
                    System.out.println(this.getNom() + " es golpeado con " + (qPuntosAtaque + this.getPuntosDefensa()) + " puntos y se defiende con " + this.getPuntosDefensa() + ". Vides: " + (this.getVides() + qPuntosAtaque) + " " + " - " + qPuntosAtaque + " = " + this.getVides());

                } else {
                    System.out.println(this.getNom() + " es golpeado con " + (qPuntosAtaque + this.getPuntosDefensa()) + " puntos y se defiende con " + this.getPuntosDefensa() + ". Vides: " + (this.getVides() + qPuntosAtaque) + " " + " - " + qPuntosAtaque + " = " + "muerta");
                }
            }
        }

    }
}
