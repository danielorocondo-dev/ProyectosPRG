package personajes;

import altres.Poder;

public class Humano extends Jugador {

    public Humano(String nom, int puntosAtaque, int puntosDefensa, int vides) {
        super(nom, puntosAtaque, puntosDefensa, vides);
        if (this.getVides() > 100) {
            setVides(100);
        }
        System.out.println("Soy un constructor de Humano pero estoy creando un " + this.getClass().getSimpleName());
    }

    @Override
    protected void esGolpeadoConCantidad(int qPuntosAtaque) {
        int defensaExtra = 0;
        for (Poder podere : this.getPoderes()) {
            if (this.getPoderes().contains(podere)) {
                defensaExtra += podere.getBonusDefensa();
            }
        }
        if (this.getPuntosDefensa()+defensaExtra > 0) {
            qPuntosAtaque -= this.getPuntosDefensa()+defensaExtra;
        }
        this.setVides(this.getVides() - qPuntosAtaque);
        System.out.println(this.getNom() + " es golpeado con " + (qPuntosAtaque + this.getPuntosDefensa()) + " puntos y se defiende con " + this.getPuntosDefensa() + ". Vides: " + (this.getVides() + qPuntosAtaque) + " " + " - " + qPuntosAtaque + " = " + this.getVides());
    }
}
