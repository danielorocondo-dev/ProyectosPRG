package personajes;

import java.util.Objects;
import java.util.ArrayList;
import altres.*;

public class Jugador {

    private String nom;
    private int puntosAtaque;
    private int puntosDefensa;
    private int vides;
    private Equip equipo;
    private ArrayList<Poder> poderes = new ArrayList();

    //CONSTRUCTOR
    public Jugador(String nom, int puntosAtaque, int puntosDefensa, int vides) {
        System.out.println("Soy un constructor de Jugador pero estoy creando un " + this.getClass().getSimpleName());
        this.nom = nom;
        this.puntosAtaque = puntosAtaque;
        this.puntosDefensa = puntosDefensa;
        this.vides = vides;
    }

    //GETTERS
    public String getNom() {
        return nom;
    }

    public Object getEquipo() {
        return equipo;
    }

    public int getPuntosAtaque() {
        return puntosAtaque;
    }

    public int getPuntosDefensa() {
        return puntosDefensa;
    }

    public int getVides() {
        return vides;
    }

    public ArrayList<Poder> getPoderes() {
        return poderes;
    }

    //////////////////
    //SETTERS
    protected void setNom(String nom) {
        this.nom = nom;
    }

    public void setEquipo(Equip equipo) {
        this.equipo = equipo;
    }

    protected void setPuntosAtaque(int puntosAtaque) {
        this.puntosAtaque = puntosAtaque;
    }

    protected void setPuntosDefensa(int puntosDefensa) {
        this.puntosDefensa = puntosDefensa;
    }

    protected void setVides(int vides) {
        this.vides = vides;
    }

    //////////////////
    public void ataca(Jugador p1) {
        System.out.println(this);
        System.out.println(p1);
        int ataqueExtra = 0;
        int ataqueExtrap1 = 0;
        for (Poder podere : poderes) {
            if (this.poderes.contains(podere)) {
                ataqueExtra += podere.getBonusAtaque();
            }

            if (p1.poderes.contains(podere)) {
                ataqueExtrap1 += podere.getBonusAtaque();
            }
        }
        p1.esGolpeadoConCantidad(this.puntosAtaque + ataqueExtra);
        this.esGolpeadoConCantidad(p1.puntosAtaque + ataqueExtrap1);
        if (this.getVides() > 0) {
            System.out.println(this);
        } else {
            System.out.println(this.getNom() + " ha muerto");
        }

        if (p1.getVides() > 0) {
            System.out.println(p1);
        } else {
            System.out.println(p1.getNom() + " ha muerto");
        }
    }

    protected void esGolpeadoConCantidad(int qPuntosAtaque) {
        int defensaExtra = 0;
        for (Poder podere : poderes) {
            if (this.poderes.contains(podere)) {
                defensaExtra += podere.getBonusDefensa();
            }
        }
        if (this.puntosDefensa + defensaExtra > 0) {
            qPuntosAtaque -= this.puntosDefensa + defensaExtra;
        }
        this.vides -= qPuntosAtaque;
        if (this.vides < 0) {
            System.out.println(getNom() + " es golpeado con " + (qPuntosAtaque + this.puntosDefensa) + " puntos y se defiende con " + this.puntosDefensa + ". Vides: " + (this.vides + qPuntosAtaque) + " " + " - " + qPuntosAtaque + " = " + "muerte");
        } else {
            System.out.println(getNom() + " es golpeado con " + (qPuntosAtaque + this.puntosDefensa) + " puntos y se defiende con " + this.puntosDefensa + ". Vides: " + (this.vides + qPuntosAtaque) + " " + " - " + qPuntosAtaque + " = " + this.vides);
        }
    }

    //////////////////
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Jugador) {
            return true;
        }
        final Jugador other = (Jugador) obj;
        return Objects.equals(this.nom, other.nom);
    }

    @Override
    public String toString() {
        String listaPoders = " tiene los poderes:\n";
        boolean existePoder = false;
        for (Poder poder : this.getPoderes()) {
            if (this.poderes.contains(poder)) {
                existePoder = true;
                listaPoders += " - " + poder.toString() + "\n";
            }
        }
        if (existePoder) {
            return getNom() + " [" + (equipo == null ? "equipo" : equipo.getNom()) + "] " + "( PA:" + getPuntosAtaque() + ", PD:" + getPuntosDefensa() + ", PV:" + getVides() + ")" + listaPoders;
        }
        return getNom() + " [" + (equipo == null ? "equipo" : equipo.getNom()) + "] " + "( PA:" + getPuntosAtaque() + ", PD:" + getPuntosDefensa() + ", PV:" + getVides() + ")";
    }
    //////////////////

    public void posa(Poder nom) {
        this.poderes.add(nom);
    }

    public void lleva(Poder nom) {
        this.poderes.remove(nom);
    }

}
